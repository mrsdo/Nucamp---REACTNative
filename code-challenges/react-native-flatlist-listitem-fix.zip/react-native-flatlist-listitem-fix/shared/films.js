export const FILMS = [
  {
    id: 0,
    title: 'Memento',
    director: 'Christopher Nolan',
    category: 'Thriller',
    language: 'English',
    year: 2000
  },
  {
    id: 1,
    title: 'Howl\'s Moving Castle',
    director: 'Hayao Miyazaki',
    category: 'Animation',
    language: 'Japanese',
    year: 2004
  }
];