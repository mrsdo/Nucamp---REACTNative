import Main from './screens/MainComponent';


export default function App() {
    return <Main />;
}


